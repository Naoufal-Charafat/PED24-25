#include <iostream>

using namespace std;

#include "tporo.h"
#include "tvectorporo.h"

int
main(void)
{
  TPoro a, b, c;
  TVectorPoro d, e, f;

  cout << "No hace nada" << endl;
}
