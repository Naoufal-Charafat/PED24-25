#include <iostream>

using namespace std;

#include "tporo.h"

int
main(void)
{
  TPoro a, b, c;

  cout << "No hace nada" << endl;
}
